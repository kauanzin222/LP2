﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio3: Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            txtResultado.Text = txtPalavra2.Text.Replace(txtPalavra1.Text, "");
        }

        private void btnInserir1_Click(object sender, EventArgs e)
        {
            char[] vetor = txtPalavra1.Text.ToCharArray();
            Array.Reverse(vetor); //inverteu

            // é um erro: txtPalavra2.Text = vetor.ToString();

            txtPalavra2.Text = "";

            /* uma forma: 
            foreach(char c in vetor)
            {
                txtPalavra2.Text += c;
            }
            */

            string auxiliar = new string(vetor); //criou uma váriavel "auxiliar" e atribui a classe string, e seu objeto era o vetor, e no fim, temos auxiliar como objeto
            txtResultado.Text = auxiliar;
        }
    }
}
