﻿namespace PTesteMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchtxtFrase = new System.Windows.Forms.RichTextBox();
            this.btnContNum = new System.Windows.Forms.Button();
            this.btnPrimSpace = new System.Windows.Forms.Button();
            this.btnContLetra = new System.Windows.Forms.Button();
            this.lblEscrever = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // rchtxtFrase
            // 
            this.rchtxtFrase.Location = new System.Drawing.Point(151, 83);
            this.rchtxtFrase.Name = "rchtxtFrase";
            this.rchtxtFrase.Size = new System.Drawing.Size(732, 305);
            this.rchtxtFrase.TabIndex = 0;
            this.rchtxtFrase.Text = "";
            // 
            // btnContNum
            // 
            this.btnContNum.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContNum.Location = new System.Drawing.Point(151, 422);
            this.btnContNum.Name = "btnContNum";
            this.btnContNum.Size = new System.Drawing.Size(189, 47);
            this.btnContNum.TabIndex = 1;
            this.btnContNum.Text = "CONTAR NÚMEROS";
            this.btnContNum.UseVisualStyleBackColor = true;
            this.btnContNum.Click += new System.EventHandler(this.btnContNum_Click);
            // 
            // btnPrimSpace
            // 
            this.btnPrimSpace.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrimSpace.Location = new System.Drawing.Point(428, 422);
            this.btnPrimSpace.Name = "btnPrimSpace";
            this.btnPrimSpace.Size = new System.Drawing.Size(189, 47);
            this.btnPrimSpace.TabIndex = 2;
            this.btnPrimSpace.Text = "1° ESPAÇO EM BRANCO";
            this.btnPrimSpace.UseVisualStyleBackColor = true;
            this.btnPrimSpace.Click += new System.EventHandler(this.btnPrimSpace_Click);
            // 
            // btnContLetra
            // 
            this.btnContLetra.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnContLetra.Location = new System.Drawing.Point(694, 422);
            this.btnContLetra.Name = "btnContLetra";
            this.btnContLetra.Size = new System.Drawing.Size(189, 47);
            this.btnContLetra.TabIndex = 3;
            this.btnContLetra.Text = "CONTAR LETRAS";
            this.btnContLetra.UseVisualStyleBackColor = true;
            this.btnContLetra.Click += new System.EventHandler(this.btnContLetra_Click);
            // 
            // lblEscrever
            // 
            this.lblEscrever.AutoSize = true;
            this.lblEscrever.Location = new System.Drawing.Point(151, 36);
            this.lblEscrever.Name = "lblEscrever";
            this.lblEscrever.Size = new System.Drawing.Size(317, 23);
            this.lblEscrever.TabIndex = 4;
            this.lblEscrever.Text = "Escreva uma frase ou um texto:";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 658);
            this.Controls.Add(this.lblEscrever);
            this.Controls.Add(this.btnContLetra);
            this.Controls.Add(this.btnPrimSpace);
            this.Controls.Add(this.btnContNum);
            this.Controls.Add(this.rchtxtFrase);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchtxtFrase;
        private System.Windows.Forms.Button btnContNum;
        private System.Windows.Forms.Button btnPrimSpace;
        private System.Windows.Forms.Button btnContLetra;
        private System.Windows.Forms.Label lblEscrever;
    }
}