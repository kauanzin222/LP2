﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio4: Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnContNum_Click(object sender, EventArgs e)
        {
            int cont = 0, contNum = 0;

            while (cont < rchtxtFrase.Text.Length)
            {
                if (Char.IsNumber(rchtxtFrase.Text[cont]))
                {
                    contNum++;
                }

                cont++;
            }

            MessageBox.Show($"O texto contém {contNum} número(s).");
        }

        private void btnPrimSpace_Click(object sender, EventArgs e)
        {
            int posicao = 0;

            for (int i = 0; i < rchtxtFrase.Text.Length; i++)
            {
                if (char.IsWhiteSpace(rchtxtFrase.Text[i]))
                {
                    posicao = i + 1;
                    break;
                }
            }

            MessageBox.Show($"A posição do 1° caracter em branco é {posicao}.");
        }

        private void btnContLetra_Click(object sender, EventArgs e)
        {
            int contaLetra = 0;
            foreach (char c in rchtxtFrase.Text)
            {
                if (char.IsLetter(c))
                {
                    contaLetra++;
                }
            }

            MessageBox.Show($"O texto tem {contaLetra} letra(s).");
        }
    }
}
