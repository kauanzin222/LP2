﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pclasses
{
    public partial class frmHorista : Form
    {
        public frmHorista()
        {
            InitializeComponent();
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void btnInstanciar_Click(object sender, EventArgs e)
        {
            Horista objHorista = new Horista();

            objHorista.NomeEmpregado = txtNome.Text;
            objHorista.Matricula = Convert.ToInt32(txtMatricula.Text);
            objHorista.DataEntradaEmpresa = Convert.ToDateTime(mskData.Text);
            objHorista.SalarioHora = Convert.ToDouble(mskSalario.Text);
            objHorista.DiasFalta = Convert.ToInt32(txtFalta.Text);
            objHorista.NumeroHora = Convert.ToDouble(txtHora.Text);

            MessageBox.Show($"Nome: {objHorista.NomeEmpregado}\nMatrícula {objHorista.Matricula}\nTempo trabalho: {objHorista.NumeroHora}\nSalário: {objHorista.SalarioBruto().ToString("N2")}");

            
        }
    }
}
