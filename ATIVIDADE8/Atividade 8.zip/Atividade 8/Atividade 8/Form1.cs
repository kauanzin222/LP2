﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_8
{
    public partial class Form1 : Form
    {
        public object MessageBoxButton { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
          
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20]; //criando um vetor de 20 números int

            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}º número", "Entrada de dados");
                if (auxiliar == "")
                    break;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show($"Digite novamente o {i+1}º número.", "NÚMERO INVÁLIDO!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    i--; //voltar o loop para inserir dnv para n se perder aquela posição
                }
            }

            Array.Reverse(vetor);
            auxiliar = ""; //limpando o array

            foreach (int dado in vetor) //não é possível imprimir o vetor como string, logo usamos o foreach para exibir cada posição da vetor...
            {
                auxiliar += dado + "\n";
            }

            MessageBox.Show(auxiliar);

            

            /*
             ....... ou

             auxiliar = "";
             auxiliar = string.Join("\n", vetor);

            */

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEx2_Click(object sender, EventArgs e)
        {
            ArrayList aluno = new ArrayList();
            aluno.AddRange(new object[] { "Ana", "André", "Camila", "João", "Joana", "Otávio", "Marcelo", "Pedro", "Thais" });

            string auxiliar = "";

            aluno.Remove("Otávio");

            for (int i = 0; i < aluno.Count; i++)
            {
                auxiliar += aluno[i] + "\n";
            }

            MessageBox.Show(auxiliar);
        }
    }
}
