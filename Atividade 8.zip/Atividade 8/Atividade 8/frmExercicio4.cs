﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade_8
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void btnExec_Click(object sender, EventArgs e)
        {
            //string[] auxiliar = new string[2];

            string[] lstBoxNomes = new string[2];

            //{"Ana Caroline", "André Machado", "Camila Queiroz", "João Nunes", "Joana Muniz", "Otávio Lopes", "Marcelo Ruioz", "Pedro Martinez", "Thais Carla", "Robson Nunes"};
            
            for (int i = 0; i < lstBoxNomes.Length; i++)
            {
                lstBoxNomes[i] = Interaction.InputBox($"Digite um nome composto: ", "Entrada de dados");
                lstbxNomes.Items.Add($"O nome {lstBoxNomes[i]} tem {lstBoxNomes[i].Replace(" ", "").Length} caracteres;\n\n");
                //auxiliar[i] = lstBoxNomes[i].Replace(" ", "");
            }
            
        }
    }
}
