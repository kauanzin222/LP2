﻿namespace PFormatacao
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnData = new System.Windows.Forms.Button();
            this.btnStringFData = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.btnStringFValor = new System.Windows.Forms.Button();
            this.btnDecimais = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(271, 217);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(166, 58);
            this.button1.TabIndex = 0;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // btnData
            // 
            this.btnData.Location = new System.Drawing.Point(445, 152);
            this.btnData.Margin = new System.Windows.Forms.Padding(4);
            this.btnData.Name = "btnData";
            this.btnData.Size = new System.Drawing.Size(166, 58);
            this.btnData.TabIndex = 1;
            this.btnData.Text = "To DateTime";
            this.btnData.UseVisualStyleBackColor = true;
            this.btnData.Click += new System.EventHandler(this.button2_Click);
            // 
            // btnStringFData
            // 
            this.btnStringFData.Location = new System.Drawing.Point(619, 217);
            this.btnStringFData.Margin = new System.Windows.Forms.Padding(4);
            this.btnStringFData.Name = "btnStringFData";
            this.btnStringFData.Size = new System.Drawing.Size(166, 58);
            this.btnStringFData.TabIndex = 2;
            this.btnStringFData.Text = "StringFormat Data";
            this.btnStringFData.UseVisualStyleBackColor = true;
            this.btnStringFData.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(619, 152);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(166, 58);
            this.button4.TabIndex = 3;
            this.button4.Text = "DateTime 2";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // btnStringFValor
            // 
            this.btnStringFValor.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStringFValor.Location = new System.Drawing.Point(445, 217);
            this.btnStringFValor.Margin = new System.Windows.Forms.Padding(4);
            this.btnStringFValor.Name = "btnStringFValor";
            this.btnStringFValor.Size = new System.Drawing.Size(166, 58);
            this.btnStringFValor.TabIndex = 4;
            this.btnStringFValor.Text = "StringFormat Valores";
            this.btnStringFValor.UseVisualStyleBackColor = true;
            this.btnStringFValor.Click += new System.EventHandler(this.button5_Click);
            // 
            // btnDecimais
            // 
            this.btnDecimais.Location = new System.Drawing.Point(271, 152);
            this.btnDecimais.Margin = new System.Windows.Forms.Padding(4);
            this.btnDecimais.Name = "btnDecimais";
            this.btnDecimais.Size = new System.Drawing.Size(166, 58);
            this.btnDecimais.TabIndex = 5;
            this.btnDecimais.Text = "To Decimais";
            this.btnDecimais.UseVisualStyleBackColor = true;
            this.btnDecimais.Click += new System.EventHandler(this.button6_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(147, 28);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(814, 27);
            this.dateTimePicker1.TabIndex = 6;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.Location = new System.Drawing.Point(18, 130);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 7;
            this.monthCalendar1.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.monthCalendar1_DateChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 658);
            this.Controls.Add(this.monthCalendar1);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.btnDecimais);
            this.Controls.Add(this.btnStringFValor);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.btnStringFData);
            this.Controls.Add(this.btnData);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnData;
        private System.Windows.Forms.Button btnStringFData;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button btnStringFValor;
        private System.Windows.Forms.Button btnDecimais;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
    }
}

