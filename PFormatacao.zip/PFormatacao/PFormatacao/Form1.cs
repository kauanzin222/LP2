﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFormatacao
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            double valor = 1255.686;

            MessageBox.Show("Moeda 3 casas decimais: " + valor.ToString("C3"));

            MessageBox.Show("Fixo 2 casas decimais: " + valor.ToString("F2"));

            MessageBox.Show("Número 2 casas decimais: " + valor.ToString("N2"));
        }

        private void button2_Click(object sender, EventArgs e)
        {
           DateTime dataexemplo  = DateTime.Now;

            MessageBox.Show("ToShortDateString: " + dataexemplo.ToShortDateString());

            MessageBox.Show("ToShortTimeString: " + dataexemplo.ToShortTimeString());

            MessageBox.Show("ToLongDateString: " + dataexemplo.ToLongDateString());

            MessageBox.Show("ToLongTimeString: " + dataexemplo.ToLongTimeString());

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string datahoje = string.Format("Hoje é {0:d} às {0:t}", DateTime.Now);
            //T maiúsculo se relaciona ao Long, enquanto minúsculo se relaciona ao Short......

            MessageBox.Show(datahoje);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double valor = 1255.686;
            
            MessageBox.Show("Moeda 3 casa decimais: " + String.Format("{0:C3}", valor));

            MessageBox.Show("Fixo 2 casa decimais: " + String.Format("{0:F2}", valor));

            MessageBox.Show("Número 2 casa decimais: " + String.Format("{0:N2}", valor));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DateTime dt = DateTime.Now;

            MessageBox.Show("Soma 2 dias: " + dt.AddHours(2).ToLongTimeString());

            MessageBox.Show("Dia da semana: " + dt.DayOfWeek.ToString());

            MessageBox.Show("Dias no mês 2/2000: " + DateTime.DaysInMonth(2000, 2));

            DateTime dt2 = Convert.ToDateTime("01/02/2023");
            DateTime dt1 = Convert.ToDateTime("06/10/2025");
            double dias = dt1.Subtract(dt2).TotalDays;
            MessageBox.Show("Diferença entre hoje e 01/02/2023: " + dias);

            if (DateTime.IsLeapYear(2024))
                MessageBox.Show("2024 é bissexto!");
            else
                MessageBox.Show("2024 não é bissexto!");
        }

        private void monthCalendar1_DateChanged(object sender, DateRangeEventArgs e)
        {
            DateTime dtEscolhida = monthCalendar1.SelectionStart;

            MessageBox.Show(dtEscolhida.ToString("d"));
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            DateTime dtEscolhida = dateTimePicker1.Value;
        }
    }
}
