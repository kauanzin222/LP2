﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms; 

namespace Pferramenta0030482421045
{
    public partial class frmFabricante : Form
    {
        private BindingSource bnFabricante = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFabricante = new DataSet();
        public frmFabricante()
        {
            InitializeComponent();
        }

        private void frmFabricante_Load(object sender, EventArgs e)
        {
            try
            {
                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                bnFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                dgvFabricante.DataSource = bnFabricante;
                bnvFabricante.BindingSource = bnFabricante;

                txtID.DataBindings.Add("TEXT", bnFabricante, "ID");
                txtNome.DataBindings.Add("TEXT", bnFabricante, "NOMEFANTASIA");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Yes or no",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Fabricante RegCat = new Fabricante();
                RegCat.Idfabricante = Convert.ToInt16(txtID.Text);

                if (RegCat.Excluir() > 0)
                {
                    MessageBox.Show("Fabricante excluída com sucesso!");

                    Fabricante R = new Fabricante();
                    dsFabricante.Tables.Clear();
                    dsFabricante.Tables.Add(R.Listar());
                    bnFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                }
                else
                {
                    MessageBox.Show("Erro ao excluir Fabricante!");
                }
            }
        }

        private void btnNovoRegistro_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);

            }

            bnFabricante.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;

            bInclusao = true;

        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 5))
            {
                MessageBox.Show("Fabricante Inválida!");

            }
            else
            {
                Fabricante RegCat = new Fabricante();

                RegCat.Idfabricante = Convert.ToInt16(txtID.Text);
                RegCat.nomeFantasia = txtNome.Text;


                if (bInclusao)
                {
                    if (RegCat.Salvar() > 0)
                    {
                        MessageBox.Show("Fabricante adicionada com sucesso!");

                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid
                        dsFabricante.Tables.Clear();
                        dsFabricante.Tables.Add(RegCat.Listar());
                        bnFabricante.DataSource = dsFabricante.Tables["Fabricante"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Fabricante!");
                    }
                }
                else // alteração
                {
                    if (RegCat.Alterar() > 0)
                    {
                        MessageBox.Show("Fabricante alterada com sucesso!");

                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = true;
                    }
                }
            }
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            if (tbFabricante.SelectedIndex == 0)
            {
                tbFabricante.SelectTab(1);
            }

            txtNome.Enabled = true;
            txtNome.Focus();
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;

            bInclusao = false;
        
     }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            bnFabricante.CancelEdit();

            txtID.Enabled = false;
            txtNome.Enabled = false;
            btnSalvar.Enabled = false;
            btnAlterar.Enabled = true;
            btnNovoRegistro.Enabled = true;
            btnExcluir.Enabled = true;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnSair_Click_1(object sender, EventArgs e)
        {
            Close();
        }

    }
}
