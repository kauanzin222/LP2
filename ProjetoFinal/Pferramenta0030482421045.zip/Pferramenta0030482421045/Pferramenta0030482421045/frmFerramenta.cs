﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pferramenta0030482421045
{
    public partial class frmFerramenta : Form
    {
        private BindingSource bnFerramenta = new BindingSource();
        private bool bInclusao = false;
        private DataSet dsFerramenta = new DataSet();
        private DataSet dsCategoria = new DataSet();
        private DataSet dsFabricante = new DataSet();
        public frmFerramenta()
        {
            InitializeComponent();
        }

        private void btnCancelar_Click_1(object sender, EventArgs e)
        {
            bnFerramenta.CancelEdit();

            txtNome.Enabled = false;
            txtSite.Enabled = false;
            cbxDistribuicao.Enabled = false;
            dtpCadastro.Enabled = false;
            cbxCategoria.Enabled = false;
            cbxFabricante.Enabled = false;

            btnNovoRegistro.Enabled = true;
            btnAlterar.Enabled = true;
            btnExcluir.Enabled = true;
            btnSalvar.Enabled = false;
            btnCancelar.Enabled = false;

            bInclusao = false;
        }

        private void btnAlterar_Click_1(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

            txtNome.Enabled = true;
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;
            
            cbxDistribuicao.SelectedIndex = 0;
            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;

            btnNovoRegistro.Enabled = false;
            btnAlterar.Enabled = false;
            btnExcluir.Enabled= false;
            btnSalvar.Enabled = true;
            btnCancelar.Enabled = true;


            bInclusao = false;
        }

        private void btnSalvar_Click_1(object sender, EventArgs e)
        {
            if (txtNome.Text == "" || (txtNome.Text.Replace(" ", "").Length < 1))
            {
                MessageBox.Show("Ferramenta Inválida!");

            }
            else if (cbxDistribuicao.SelectedIndex == -1)
            {
                MessageBox.Show("Distribuição inválida");
            }
            else if (txtSite.Text == "" || txtSite.Text.Replace(" ", "").Length < 8)
            {
                MessageBox.Show("Site Oficial Invalido");
            }
            else if(Convert.ToDateTime(dtpCadastro.Value)<DateTime.Today)
            {
                MessageBox.Show("Data invalida");
            }

            else
            {
                Ferramenta RegCat = new Ferramenta();

                RegCat.IdFerramenta = Convert.ToInt16(txtID.Text);
                RegCat.Nome = txtNome.Text;
                RegCat.Distribuicao = Convert.ToChar(cbxDistribuicao.SelectedItem);
                RegCat.dtCadastro = dtpCadastro.Value;
                RegCat.SiteOficial = txtSite.Text;
                RegCat.IdFabricante = Convert.ToInt32(cbxFabricante.SelectedValue.ToString());
                RegCat.IdCategoria = Convert.ToInt32(cbxCategoria.SelectedValue.ToString());



                if (bInclusao)
                {
                    if (RegCat.Salvar() > 0)
                    {
                        MessageBox.Show("Ferramenta adicionada com sucesso!");

                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = false;

                        //recarrega o grid
                        dsFerramenta.Tables.Clear();
                        dsFerramenta.Tables.Add(RegCat.Listar());
                        bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                    }
                    else
                    {
                        MessageBox.Show("Erro ao gravar Ferramenta!");
                    }
                }
                else // alteração
                {
                    if (RegCat.Alterar() > 0)
                    {
                        MessageBox.Show("Ferramenta alterada com sucesso!");

                        txtID.Enabled = false;
                        txtNome.Enabled = false;
                        btnSalvar.Enabled = false;
                        btnAlterar.Enabled = true;
                        btnNovoRegistro.Enabled = true;
                        btnExcluir.Enabled = true;
                        btnCancelar.Enabled = false;

                        bInclusao = true;
                    }
                }
            }
        }

        private void btnExcluir_Click_1(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);
            }

            if (MessageBox.Show("Confirma exclusão?", "Yes or no",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Ferramenta RegCat = new Ferramenta();
                RegCat.IdFerramenta = Convert.ToInt16(txtID.Text);

                if (RegCat.Excluir() > 0)
                {
                    MessageBox.Show("Ferramenta excluída com sucesso!");

                   dsFerramenta.Tables.Clear();
                    dsFerramenta.Tables.Add(RegCat.Listar());
                    bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];

                }
                else
                {
                    MessageBox.Show("Erro ao excluir Ferramenta!");
                }
            }
        }

        private void btnNovoRegistro_Click_1(object sender, EventArgs e)
        {
            if (tbFerramenta.SelectedIndex == 0)
            {
                tbFerramenta.SelectTab(1);

            }

            bnFerramenta.AddNew();
            txtNome.Enabled = true;
            txtNome.Focus();
            txtSite.Enabled = true;
            cbxDistribuicao.Enabled = true;
            dtpCadastro.Enabled = true;
            cbxCategoria.Enabled = true;
            cbxFabricante.Enabled = true;

            cbxCategoria.SelectedIndex = 0;
            cbxFabricante.SelectedIndex = 0;
            cbxDistribuicao.SelectedIndex = 0;

            btnNovoRegistro.Enabled = false;
            btnSalvar.Enabled = true;
            btnAlterar.Enabled = false;
            btnNovoRegistro.Enabled = false;
            btnExcluir.Enabled = false;
            btnCancelar.Enabled = true;
           
            bInclusao = true;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void frmFerramenta_Load(object sender, EventArgs e)
        {
            try
            {
                Ferramenta RegFer = new Ferramenta();
                dsFerramenta.Tables.Add(RegFer.Listar());
                bnFerramenta.DataSource = dsFerramenta.Tables["Ferramenta"];
                dgvFerramenta.DataSource = bnFerramenta;
                bnvFerramenta.BindingSource = bnFerramenta;

                txtID.DataBindings.Add("TEXT", bnFerramenta, "ID");
                txtNome.DataBindings.Add("TEXT", bnFerramenta, "nome");
                cbxDistribuicao.DataBindings.Add("SelectedItem", bnFerramenta, "distribuicao");
                dtpCadastro.DataBindings.Add("TEXT", bnFerramenta, "dtcadastro");
                txtSite.DataBindings.Add("TEXT", bnFerramenta, "siteoficial");

                // carrega dados da Categoria

                Categoria RegCat = new Categoria();
                dsCategoria.Tables.Add(RegCat.Listar());
                cbxCategoria.DataSource = dsCategoria.Tables["Categoria"];
                cbxCategoria.DisplayMember = "descricao";
                cbxCategoria.ValueMember = "id";
                cbxCategoria.DataBindings.Add("SelectedValue", bnFerramenta, "idCategoria");

                Fabricante RegFab = new Fabricante();
                dsFabricante.Tables.Add(RegFab.Listar());
                cbxFabricante.DataSource = dsFabricante.Tables["Fabricante"];
                cbxFabricante.DisplayMember = "nomefantasia";
                cbxFabricante.ValueMember = "id";
                cbxFabricante.DataBindings.Add("SelectedValue", bnFerramenta, "idFabricante");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dtpCadastro_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void txtSite_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
