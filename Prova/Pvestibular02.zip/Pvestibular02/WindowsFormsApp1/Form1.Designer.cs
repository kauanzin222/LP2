﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReceber = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.lstbxVestibular = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // btnReceber
            // 
            this.btnReceber.Location = new System.Drawing.Point(81, 70);
            this.btnReceber.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReceber.Name = "btnReceber";
            this.btnReceber.Size = new System.Drawing.Size(241, 68);
            this.btnReceber.TabIndex = 0;
            this.btnReceber.Text = "Receber dados";
            this.btnReceber.UseVisualStyleBackColor = true;
            this.btnReceber.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(81, 202);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(241, 68);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Limpar";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // lstbxVestibular
            // 
            this.lstbxVestibular.FormattingEnabled = true;
            this.lstbxVestibular.ItemHeight = 19;
            this.lstbxVestibular.Location = new System.Drawing.Point(629, 12);
            this.lstbxVestibular.Name = "lstbxVestibular";
            this.lstbxVestibular.Size = new System.Drawing.Size(398, 574);
            this.lstbxVestibular.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 658);
            this.Controls.Add(this.lstbxVestibular);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnReceber);
            this.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnReceber;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.ListBox lstbxVestibular;
    }
}

