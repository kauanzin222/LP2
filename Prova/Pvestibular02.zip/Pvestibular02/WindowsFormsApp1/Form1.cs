﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[,] curso = new int[2, 5];
            int auxiliar, totalCurso = 0, totalGeral = 0;

            for (int i = 0; i < 2; i++)
                for (int j = 0; j < 5; j++)
                {
                    if (int.TryParse(Interaction.InputBox($"Digite o total de aluno do curso {i+1}  no ano {j+1}", "Total de alunos de cada curso e ano."), out auxiliar))
                    {
                        if (auxiliar >= 0)
                        {
                            curso[i, j] = auxiliar;
                            lstbxVestibular.Items.Add($"Total do curso {i + 1} do ano {j + 1}: {curso[i, j]}");
                            totalCurso += curso[i, j];
                            totalGeral += curso[i, j];
                        }
                        else
                        {
                            MessageBox.Show($"Digite novamente o total de alunos do curso {i+1} do ano {j+1}", "NÚMERO INVÁLIDO!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            j--;
                        }
                    }
                    else
                    {
                        MessageBox.Show($"Digite novamente o total de alunos do curso {i + 1} do ano {j + 1}", "NÚMERO INVÁLIDO!!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        j--;
                    }
                    if (j == 4)
                    {
                        lstbxVestibular.Items.Add("");
                        lstbxVestibular.Items.Add($" --> Total curso {i+1}: {totalCurso}");
                        lstbxVestibular.Items.Add("");
                        lstbxVestibular.Items.Add("______________________________________________________________________________");

                        totalCurso = 0;
                    }
                }

            lstbxVestibular.Items.Add("");
            lstbxVestibular.Items.Add($" --> Total Geral: {totalGeral}");


        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            lstbxVestibular.Items.Clear();
        }
    }
}
