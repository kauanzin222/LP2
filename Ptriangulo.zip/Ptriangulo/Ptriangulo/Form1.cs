﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1: Form
    {
        float numA, numB, numC, auxA, auxB, auxC;


        private void txtB_Validated(object sender, EventArgs e)
        {
            if (!float.TryParse(txtB.Text, out numB) || numB == 0)
            { 
                MessageBox.Show("Valor B inválido!");
                txtB.Focus();
            }
        }

        private void txtC_Validated(object sender, EventArgs e)
        {
            if (!float.TryParse(txtC.Text, out numC) || numC == 0)
            {
                MessageBox.Show("Valor C inválido!");
                txtC.Focus();
                
            }
        }

        private void txtA_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
            }
        }

        private void txtA_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyData == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                SelectNextControl(ActiveControl, true, true, true, true);
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtA.Clear();
            txtB.Clear();
            txtC.Clear();
            txtTipo.Clear();
        }

        private void txtTipo_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtTipo_Validated(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            auxA = numB - numC;
            auxB = numA - numC;
            auxC = numA - numB;

            if (Math.Abs(auxA) < numA && numB + numC > numA && Math.Abs(auxB) < numB && numA + numC > numB && Math.Abs(auxC) < numC && numA + numB > numC)
                MessageBox.Show("É um triângulo!");
            else
                MessageBox.Show("Não é um triângulo!");

            if (numA == numB && numA == numC)
                txtTipo.Text = "EQUILÁTERO";
            else
                if (numA != numB && numA != numC && numB != numC)
                txtTipo.Text = "ESCALENO";
            else
                txtTipo.Text = "ISÓSELES";
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void txtA_Validated(object sender, EventArgs e)
        {
            if (!float.TryParse(txtA.Text, out numA) || numA == 0)
            {
                MessageBox.Show("Valor A inválido!");
                txtA.Focus();
            }
        }
    }
}
