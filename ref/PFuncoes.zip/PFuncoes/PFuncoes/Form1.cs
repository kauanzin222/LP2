﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PFuncoes
{
    public partial class Início : Form
    {
        public Início()
        {
            InitializeComponent();
        }

        void Soma1()
        {
            double resultado = 2 + 3;
            MessageBox.Show($"O resultado é: {resultado}");   
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            Soma1();
        }

        double Soma2()
        {
            double resultado = 2 + 6;
            return resultado;
        }

        private void btnSoma2_Click(object sender, EventArgs e)
        {
            double auxiliar = Soma2();

            MessageBox.Show(auxiliar.ToString());

            // mbox.show(soma2().tostring());
        }

        void Soma3(double x, double y)
        {
            x = 40;
            double resultado = x + y;

            MessageBox.Show($"O resultado é: {resultado.ToString()}");
        }

        private void btnSoma3_Click(object sender, EventArgs e)
        {
            Soma3(3, 2);
        }

        double Soma4(double x, double y)
        {
            double resultado = x + y;
            return resultado; //ou return x+ y;
        }

        private void btnSoma4_Click(object sender, EventArgs e)
        {
            MessageBox.Show($"O resultado é: {Soma4(3, 2)}");
        }

        void Soma5(ref double resultado, ref double a)
        {
            a = 40;
            resultado = 2 + 3;
        }

        private void btnSoma5_Click(object sender, EventArgs e)
        {
            double r = 0;
            double x = 20;
            
            Soma5(ref r, ref x);
            MessageBox.Show($"O valor de x é: {x}\nO valor de r é: {r}");
            //MessageBox.Show($"O valor de r é: {r}");
        }
        
        double Soma6(ref double dobro, double x, double y)
        {
            dobro = (x + y) * 2;
            return x + y;
        }

        private void btnSoma6_Click(object sender, EventArgs e)
        {
            double x = 2;
            double y = 5;
            double dobro = 0;

            MessageBox.Show($"A soma é: {Soma6(ref dobro, x, y)}  \n\nO dobro é: {dobro}");
        }

    }
}
